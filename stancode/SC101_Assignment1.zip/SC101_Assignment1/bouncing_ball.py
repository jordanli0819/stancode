"""
File: 
Name:
-------------------------
TODO:
"""

from campy.graphics.gobjects import GOval
from campy.graphics.gwindow import GWindow
from campy.gui.events.timer import pause
from campy.gui.events.mouse import onmouseclicked

VX = 3
DELAY = 30
GRAVITY = 1
SIZE = 20
REDUCE = 0.9
START_X = 30
START_Y = 40

window = GWindow(800, 500, title='bouncing_ball.py')
circle = GOval(SIZE, SIZE)


def main():
    """
    This program simulates a bouncing ball at (START_X, START_Y)
    that has VX as x velocity and 0 as y velocity. Each bounce reduces
    y velocity to REDUCE of itself.
    """
    circle.filled = True
    circle.color = 'navy'
    circle.fill_color = 'navy'
    window.add(circle, START_X, START_Y)
    onmouseclicked(ball)


def ball(bounce):
    n = 0
    if circle.x == START_X and circle.y == START_Y:
        while True:
            g = GRAVITY*n
            n += 1
            circle.move(VX, g)
            if circle.y + SIZE >= window.height:
                n = -n * REDUCE
            if circle.x >= window.width:
                break
            pause(DELAY)
        window.add(circle, START_X, START_Y)
    else:
        pass


if __name__ == "__main__":
    main()
