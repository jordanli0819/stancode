"""
File: 
Name:
-------------------------
TODO:
"""

from campy.graphics.gobjects import GOval, GLine
from campy.graphics.gwindow import GWindow
from campy.gui.events.mouse import onmouseclicked


window = GWindow()
cir = GOval(10, 10)


def main():
    """
    This program creates lines on an instance of GWindow class.
    There is a circle indicating the user’s first click. A line appears
    at the condition where the circle disappears as the user clicks
    on the canvas for the second time.
    """
    onmouseclicked(circle)


def circle(c):
    cir.filled = False
    cir.color = 'teal'
    window.add(cir, c.x-cir.width/2, c.y-cir.height/2)
    onmouseclicked(line)


def line(li):
    draw = GLine(cir.x+5, cir.y+5, li.x, li.y)
    draw.color = 'teal'
    window.add(draw)
    window.remove(cir)
    onmouseclicked(circle)


if __name__ == "__main__":
    main()
