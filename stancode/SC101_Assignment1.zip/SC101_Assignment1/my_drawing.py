"""
File: NBA Championship BUCKS
Name:
----------------------
TODO:
"""

from campy.graphics.gobjects import GOval, GRect, GPolygon , GLine ,GLabel
from campy.graphics.gwindow import GWindow


def main():
    """
    TODO: NBA Championship BUCKS
    """
    window = GWindow(500,700)
    court = GRect(400, 600, x=50, y=50)
    court.filled = True
    court.fill_color = 'burlywood'
    window.add(court)
    court1 = GLine(50, 350, 450, 350)
    window.add(court1)
    court2 = GOval(100, 100, x=200, y=300)
    window.add(court2)
    word = GLabel('2021')
    word.color = 'red'
    word.font = 'Verdana-50-bold'
    window.add(word, x=70,y=175)
    word2 = GLabel('Championships')
    word2.color = 'gold'
    word2.font = 'Courier-35-bold-italic'
    window.add(word2, x=70, y=250)
    word3 = GLabel('NBA')
    word3.color = 'blue'
    word3.font = 'Verdana-50-bold'
    window.add(word3, x=275, y=175)
    word4 = GLabel('BUCKS')
    word4.color = 'seagreen'
    word4.font = 'Verdana-50-bold'
    window.add(word4, x=125, y=640)
    bucks = GPolygon()   # up face
    bucks.add_vertex((200, 450))
    bucks.add_vertex((300, 450))
    bucks.add_vertex((250, 500))
    bucks.filled = True
    bucks.fill_color = 'seagreen'
    window.add(bucks)
    bucks1 = GPolygon()   # down face
    bucks1.add_vertex((250, 500))
    bucks1.add_vertex((200, 550))
    bucks1.add_vertex((300, 550))
    bucks1.filled = True
    bucks1.fill_color = 'seagreen'
    window.add(bucks1)
    bucks2 = GPolygon()   # left face
    bucks2.add_vertex((250, 500))
    bucks2.add_vertex((200, 550))
    bucks2.add_vertex((235, 485))
    bucks2.filled = True
    bucks2.fill_color = 'seagreen'
    window.add(bucks2)
    bucks3 = GPolygon()    # right face
    bucks3.add_vertex((250, 500))
    bucks3.add_vertex((300, 550))
    bucks3.add_vertex((265, 485))
    bucks3.filled = True
    bucks3.fill_color = 'seagreen'
    window.add(bucks3)
    bucks4 = GPolygon()  # nose
    bucks4.add_vertex((242, 485))
    bucks4.add_vertex((258, 485))
    bucks4.add_vertex((250, 490))
    bucks4.filled = True
    bucks4.fill_color = 'black'
    window.add(bucks4)
    bucks5 = GPolygon()  # left eye
    bucks5.add_vertex((230, 465))
    bucks5.add_vertex((240, 465))
    bucks5.add_vertex((235, 470))
    bucks5.filled = True
    bucks5.fill_color = 'white'
    window.add(bucks5)
    bucks6 = GPolygon()  # left eye
    bucks6.add_vertex((270, 465))
    bucks6.add_vertex((260, 465))
    bucks6.add_vertex((265, 470))
    bucks6.filled = True
    bucks6.fill_color = 'white'
    window.add(bucks6)
    bucks7 = GPolygon()  # left main antler
    bucks7.add_vertex((225, 450))
    bucks7.add_vertex((240, 450))
    bucks7.add_vertex((175, 380))
    bucks7.filled = True
    bucks7.fill_color = 'seagreen'
    window.add(bucks7)
    bucks8 = GPolygon()  # left  antler (left)
    bucks8.add_vertex((195, 408))
    bucks8.add_vertex((200, 415))
    bucks8.add_vertex((165, 410))
    bucks8.filled = True
    bucks8.fill_color = 'seagreen'
    window.add(bucks8)
    bucks9 = GPolygon()  # left  antler (right)
    bucks9.add_vertex((200, 407))
    bucks9.add_vertex((210, 417))
    bucks9.add_vertex((200, 380))
    bucks9.filled = True
    bucks9.fill_color = 'seagreen'
    window.add(bucks9)
    bucks10 = GPolygon()  # right main antler
    bucks10.add_vertex((275, 450))
    bucks10.add_vertex((260, 450))
    bucks10.add_vertex((325, 380))
    bucks10.filled = True
    bucks10.fill_color = 'seagreen'
    window.add(bucks10)
    bucks11 = GPolygon()  # right antler (left)
    bucks11.add_vertex((300, 415))
    bucks11.add_vertex((310, 402))
    bucks11.add_vertex((340, 390))
    bucks11.filled = True
    bucks11.fill_color = 'seagreen'
    window.add(bucks11)
    bucks12 = GPolygon()  # right antler (left)
    bucks12.add_vertex((295, 413))
    bucks12.add_vertex((302, 404))
    bucks12.add_vertex((295, 380))
    bucks12.filled = True
    bucks12.fill_color = 'seagreen'
    window.add(bucks12)



if __name__ == '__main__':
    main()
