"""
stanCode Breakout Project
Adapted from Eric Roberts's Breakout by
Sonja Johnson-Yu, Kylie Jue, Nick Bowman, 
and Jerry Liao

YOUR DESCRIPTION HERE
"""
from campy.graphics.gwindow import GWindow
from campy.graphics.gobjects import GOval, GRect, GLabel
from campy.gui.events.mouse import onmousemoved, onmouseclicked
import random

BRICK_SPACING = 5      # Space between bricks (in pixels). This space is used for horizontal and vertical spacing.
BRICK_WIDTH = 40       # Height of a brick (in pixels).
BRICK_HEIGHT = 15      # Height of a brick (in pixels).
BRICK_ROWS = 10        # Number of rows of bricks.
BRICK_COLS = 10        # Number of columns of bricks.
BRICK_OFFSET = 50      # Vertical offset of the topmost brick from the window top (in pixels).
BALL_RADIUS = 10       # Radius of the ball (in pixels).
PADDLE_WIDTH = 75      # Width of the paddle (in pixels).
PADDLE_HEIGHT = 15     # Height of the paddle (in pixels).
PADDLE_OFFSET = 50     # Vertical offset of the paddle from the window bottom (in pixels).

INITIAL_Y_SPEED = 7  # Initial vertical speed for the ball.
MAX_X_SPEED = 5   # Maximum initial horizontal speed for the ball.
WINDOW_WIDTH = BRICK_COLS * (BRICK_WIDTH + BRICK_SPACING) - BRICK_SPACING
WINDOW_HEIGHT = BRICK_OFFSET + 3 * (BRICK_ROWS * (BRICK_HEIGHT + BRICK_SPACING) - BRICK_SPACING)
# global variables
paddle = GRect(PADDLE_WIDTH, PADDLE_HEIGHT)
ball = GOval(BALL_RADIUS*2, BALL_RADIUS*2)


class BreakoutGraphics:

    def __init__(self, ball_radius=BALL_RADIUS, paddle_width=PADDLE_WIDTH,
                 paddle_height=PADDLE_HEIGHT, paddle_offset=PADDLE_OFFSET,
                 brick_rows=BRICK_ROWS, brick_cols=BRICK_COLS,
                 brick_width=BRICK_WIDTH, brick_height=BRICK_HEIGHT,
                 brick_offset=BRICK_OFFSET, brick_spacing=BRICK_SPACING,
                 title='Breakout'):

        # Create a graphical window, with some extra space
        window_width = brick_cols * (brick_width + brick_spacing) - brick_spacing
        window_height = brick_offset + 3 * (brick_rows * (brick_height + brick_spacing) - brick_spacing)
        self.window = GWindow(width=window_width, height=window_height, title=title)

        self.life = GLabel('LIFE:')
        self.life.font = '-20'
        self.window.add(self.life, 0, self.life.height+5)

        self.paddle = paddle
        self.paddle.filled = True
        self.paddle.fill_color = 'black'
        self.window.add(self.paddle, x=(window_width-paddle_width)/2, y=(window_height-paddle_offset - paddle_height))

        self.zone = GRect(window_width, ball_radius)
        self.zone.filled = True
        self.zone.color = 'white'
        self.zone.fill_color = 'white'
        self.window.add(self.zone, 0, window_height-ball_radius)

        self.ball = ball
        self.ball.filled = True
        self.ball.fill_color = 'black'
        self.window.add(self.ball, x=(window_width-ball_radius*2)/2, y=(window_height-ball_radius*2)/2)

        self.__vx = random.randint(1, MAX_X_SPEED)
        if random.random() > 0.5:
            self.__vx = -self.__vx
        self.__vy = INITIAL_Y_SPEED

        for i in range(brick_rows):
            for j in range(brick_cols):
                if j < 2:
                    self.brick = GRect(brick_width, brick_height)
                    self.brick.filled = True
                    self.brick.fill_color = 'red'
                    self.brick.color = 'red'
                elif 2 <= j < 4:
                    self.brick = GRect(brick_width, brick_height)
                    self.brick.filled = True
                    self.brick.fill_color = 'orange'
                    self.brick.color = 'orange'
                elif 4 <= j < 6:
                    self.brick = GRect(brick_width, brick_height)
                    self.brick.filled = True
                    self.brick.fill_color = 'yellow'
                    self.brick.color = 'yellow'
                elif 6 <= j < 8:
                    self.brick = GRect(brick_width, brick_height)
                    self.brick.filled = True
                    self.brick.fill_color = 'green'
                    self.brick.color = 'green'
                elif 8 <= j < 10:
                    self.brick = GRect(brick_width, brick_height)
                    self.brick.filled = True
                    self.brick.fill_color = 'blue'
                    self.brick.color = 'blue'
                x = (brick_width+brick_spacing)*i
                y = brick_offset+(brick_height+brick_spacing)*j
                self.window.add(self.brick, x, y)

        onmousemoved(move)
        self._started = 0  # 開始的初始值 onmouseclicked()
        onmouseclicked(self.change_status)   # 開始的開關

    def detect_brick(self):
        detect = self.window.get_object_at(self.ball.x+BALL_RADIUS*2, self.ball.y+BALL_RADIUS*2)
        return detect

    def remove_brick(self, brick):
        if self.detect_brick() is not None:
            self.__vx = -self.__vx
            self.__vy = -self.__vy
            self.window.remove(brick)

    def rebound(self):
        if self.detect_brick() is self.paddle:
            self.__vy = -self.__vy

    def again(self):
        self._started = 0
        self.window.remove(self.ball)
        self.window.add(self.ball, x=(self.window.width - BALL_RADIUS * 2) / 2,
                        y=(self.window.height - BALL_RADIUS * 2) / 2)

    def change_status(self, mouse):  # 要加上mouse(滑鼠游標的箱子) 因為是在class裡面的function
        self._started += 1

    def get_started(self):
        return self._started

    def get_dx(self):
        # getter
        return self .__vx

    def get_dy(self):
        # getter
        return self.__vy

    def set_dx(self):
        #  setter
        self.__vx *= -1

    def set_dy(self):
        # setter
        self.__vy *= -1


def move(mouse):
    if mouse.x >= paddle.width:
        paddle.x = mouse.x-paddle.width


def main():
    BreakoutGraphics()

# Create a paddle
# Center a filled ball in the graphical window
# Default initial velocity for the ball 2
# Initialize our mouse listeners 2
# Draw bricks


if __name__ == '__main__':
    main()
