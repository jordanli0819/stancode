"""
File: extension.py
--------------------------
This file collects more data from
https://www.ssa.gov/oact/babynames/decades/names2010s.html
https://www.ssa.gov/oact/babynames/decades/names2000s.html
https://www.ssa.gov/oact/babynames/decades/names1990s.html
Please print the number of top200 male and female on Console
You should see:
---------------------------
2010s
Male Number: 10890537
Female Number: 7939153
---------------------------
2000s
Male Number: 12975692
Female Number: 9207577
---------------------------
1990s
Male Number: 14145431
Female Number: 10644002
"""

import requests
from bs4 import BeautifulSoup


def main():
    for year in ['2010s', '2000s', '1990s']:
        print('---------------------------')
        print(year)
        url = 'https://www.ssa.gov/oact/babynames/decades/names'+year+'.html'
        ##################
        #                #
        #      TODO:     #
        #                #
        ##################
        male3 = []
        female3 = []

        response = requests.get(url)

        html = response.text

        soup = BeautifulSoup(html)
        items = soup.find_all('table', {'class', 't-stripe'})  # 讓他變成object
        male = 0
        female = 0

        for i in range(200):
            x = 2+5*i
            y = 4+5*i

            for item in items:
                number = item.tbody.find_all('td')
                male1 = number[x].text
                female1 = number[y].text
                male2 = ''
                female2 = ''

                for j in range(len(male1)):
                    if male1[j] is ',':
                        pass
                    else:
                        male2 += male1[j]
                for k in range(len(female1)):
                    if female1[k] is ',':
                        pass
                    else:
                        female2 += female1[k]
                male += int(male2)
                female += int(female2)
                male3.append(male)
                female3.append(female)
        print('Male Number:', str(male3[len(male3)-1]), 'Female Number:', str(female3[len(male3)-1]))




if __name__ == '__main__':
    main()
